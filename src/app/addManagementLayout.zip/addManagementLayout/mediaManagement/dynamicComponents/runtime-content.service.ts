import {Injectable} from "@angular/core";
import {Http, Headers,Response, RequestOptions} from "@angular/http";
import "rxjs/Rx";
import {Observable} from "rxjs";
import {Credentials} from "./credentials";
import {SessionStorageService} from "ngx-webstorage";
import {UrlProvider} from "../../../commonServices/urlProvider";
@Injectable()
export class RunTimeDataProviderService{
    constructor(private http:Http, private url:UrlProvider, private storage:SessionStorageService)
    {

    }

      public getJSON(fileWithPath:string): Observable<any> {
        return this.http.get(fileWithPath)
                        .map((res:any) => /*res.json()*/res);
                        //.catch((error:any) => console.log(error));
      }

}
