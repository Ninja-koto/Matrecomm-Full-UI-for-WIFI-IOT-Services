import {Component,OnInit,ElementRef} from "@angular/core"
import {BaThemeSpinner} from "../../../theme/services";
import { FormGroup, FormControl, FormBuilder, Validators, } from '@angular/forms';
import {Http, Headers,Response, RequestOptions} from "@angular/http";
import "rxjs/Rx";
import {Observable} from "rxjs";
import * as jQuery from "jquery";
import {RPCService} from "../../../commonServices/RPC.service";
import {CustomValidator} from "../../../commonServices/customValidator.service";
import {Logger} from "../../../commonServices/logger";
import {SessionStorageService} from "ngx-webstorage";
import {UrlProvider} from "../../../commonServices/urlProvider";
import { CollectionTableDataCollectorService } from '../../../commonServices/tableDataCollector.service';
import {NameSpaceUtil} from "../../../commonServices/nameSpaceUtil";
import { FileUploader } from 'ng2-file-upload';

@Component({
    selector:"media-store",
    templateUrl:'mediaStore.component.html',
    providers:[RPCService, CollectionTableDataCollectorService]
})

export class MediaStoreManagement implements OnInit {
    public myForm: FormGroup;
    progressStatus:Number=0;

    httpCall:XMLHttpRequest;
    uploadedFiles:any=[];
    selectFileErrmsg:String="";
    fileDataCollected:Boolean=false;
    selectedFilesList:FileList;
    canProceedToUpload:Boolean=false;

    public uploader:FileUploader = new FileUploader({url: "http://127.0.0.1:4000/tableData/upload",
    additionalParameter:{"fileNS":"abc.xyz"}});
    nsObj:NameSpaceUtil;
    constructor(private _spinner:BaThemeSpinner,private _fb: FormBuilder, private el: ElementRef,
        private tableDataCollectService:CollectionTableDataCollectorService,
        private clientRpc: RPCService, private http:Http,private storage:SessionStorageService, private url:UrlProvider) {
        this._spinner.show();
        this.nsObj = new NameSpaceUtil(this.storage);
      }
      ngOnInit(){
        this.myForm = this._fb.group({
            fileName: ['', []],//[Validators.required, Validators.minLength(5)]],
            adFile: ['', []],
        });
        //override the onAfterAddingfile property of the uploader so it doesn't authenticate with //credentials.
        this.uploader.onAfterAddingFile = (file)=> { file.withCredentials = false; };
        //overide the onCompleteItem property of the uploader so we are
        //able to deal with the server response.
        this.uploader.onCompleteItem = (item:any, response:any, status:any, headers:any) => {
            console.log("ImageUpload:uploaded:", item, status, response);
        };
        this.getUploadedFilesData();
        this.subcribeToFormChanges();
      }



      ngAfterViewInit(){
        //this._spinner.hide();
      }

    getUploadedFilesData(){
    console.log("In getUploadedFilesData");
    console.log(new Date());

        try{

        var paramsForData={};
        let query={}, projectQuery={};
        paramsForData["projectQuery"]=projectQuery;
        paramsForData["dataQuery"]= query;
        paramsForData["namespace"]= this.nsObj.getNameSpace("uploads.files");
        paramsForData["limit"]=-1;
        console.log(paramsForData);

        this.tableDataCollectService.getPostData(paramsForData)
            .subscribe(result => {
                var res = result;//json();
                console.log("UPloaded Files");
                console.log(res.data);
                if(res!=undefined)
                {
                if(res.data==undefined)
                    this.uploadedFiles=[];
                else
                    this.uploadedFiles=res.data
                }
                else
                    this.uploadedFiles=[];
                console.log(this.uploadedFiles);
                //this.myForm.controls.adFile.reset();
                //this.myForm.reset();
                this.fileDataCollected=true;
                this._spinner.hide();
        });

        }
        catch(e)
        {
        this._spinner.hide();
        console.log("getUploadedFilesData Failed... ");
        }


      }

      upload() {
        //locate the file element meant for the file upload.
            let inputEl: HTMLInputElement = this.el.nativeElement.querySelector('#photo');
        //get the total amount of files attached to the file input.
            let fileCount: number = inputEl.files.length;
        //create a new fromdata instance
            let formData = new FormData();
        //check if the filecount is greater than zero, to be sure a file was selected.
            if (fileCount > 0) { // a file was selected
                //append the key name 'photo' with the first file in the element
                console.log(inputEl.files.item(0));
                let fileName = inputEl.files.item(0).name;
                let Ext = '.' + fileName.split('.')[fileName.split('.').length -1]
                console.log(Ext);
                    formData.append('file', inputEl.files.item(0),"abc"+Ext);
                    //formData.append('fileName','abc.mp4');
                //call the angular http method

                this.http
            //post the form data to the url defined above and map the response. Then subscribe //to initiate the post. if you don't subscribe, angular wont post.
                    .post("http://127.0.0.1:4000/tableData/upload", formData).map((res:Response) => res.json()).subscribe(
                    //map the success function and alert the response
                     (success) => {
                             alert(success._body);
                    },
                    (error) => alert(error))
              }
           }

    checkNameAlreadyExist(e){
        console.log("In checkNameAlreadyExist")
        console.log(e);
        if(this.uploadedFiles!=undefined)
        {
            let found=false;
            for(let i=0;i<this.uploadedFiles.length;i++)
            {
                if(this.uploadedFiles[i].filename==e)
                {
                    found=true;
                    break;
                }
            }
            if(found) return true;
            else return false;
        }
        else
        return false;
    }
    getLocalTime(value){
    return String(new Date(value).toLocaleDateString())+", "+String(new Date(value).toLocaleTimeString());
    }

    fileChange_New(event) {
        let fileList: FileList = event.target.files;
        this.selectedFilesList = fileList;
        let status= this.canWeProceedToUpload();
        //console.log(status);
        //if(status)
            this.canProceedToUpload=true;
        //else
        //    this.canProceedToUpload=false;
    }
    fileNameChanged(e){
        //console.log("File Name changed..");
        //console.log(e);
        let status= this.canWeProceedToUpload();
        //console.log(status);
        if(status)
            this.canProceedToUpload=true;
        else
            this.canProceedToUpload=false;
    }

    canWeProceedToUpload(){
        //console.log("IN canWeProceed");
        //console.log(this.myForm.controls.fileName.value);
        let fileName=this.myForm.controls.fileName.value;
        this.canProceedToUpload=false;
        let fileNameOk=false, selectFileOk=false;
        if(fileName==undefined)
        {
            this.myForm.controls["fileName"].setErrors({"required":true});
            return false;
        }
        if(fileName=="")
            this.myForm.controls["fileName"].setErrors({"required":true});
        else if(fileName.length<5)
            this.myForm.controls["fileName"].setErrors({
                "minlength":{"requiredLength":5,"actualLength":fileName.length}
            });
        else
        {
            this.myForm.controls["fileName"].setErrors(null);
            fileNameOk=true;
        }

        //console.log(this.selectedFilesList);
        if(this.selectedFilesList==undefined)
        {
            this.selectFileErrmsg="Please Select file";
            return false;
        }
        else
        {
            this.selectFileErrmsg="";
            selectFileOk=true;
        }
        if(fileNameOk&&selectFileOk)
            return true;
        else
            return false;
    }

    uploadFile(e){
        this.canProceedToUpload=false;
        let fileList=this.selectedFilesList;
        if(fileList.length > 0) {
            let file: File = fileList[0];
            let formData:FormData = new FormData();
            console.log(file);
            console.log(file.name);
            let shortName = this.myForm.controls.fileName.value;
            let fileName = file.name;
            let Ext = '.' + fileName.split('.')[fileName.split('.').length -1]
            let status = this.checkNameAlreadyExist(shortName+Ext);
            if(!status)
            {
                this.selectFileErrmsg="";
                let prodName = this.storage.retrieve("productMgrName");
                let orgId = this.storage.retrieve("orgMgrUUID");
                let name= fileName.substr(0,fileName.lastIndexOf("."))+"_"+prodName+"_"+orgId;
                console.log(name+Ext);
                formData.append('file', file, name+Ext );

                this.httpCall= new XMLHttpRequest();
                this.httpCall.upload.addEventListener("progress",this.progressHnadler.bind(this),false);
                this.httpCall.addEventListener("load",this.completeHandler.bind(this),false);
                this.httpCall.addEventListener("error",this.errorHandler.bind(this),false);
                this.httpCall.addEventListener("abort",this.abortHandler.bind(this),false);
                //let headers = new Headers();
                this.httpCall.open("post",this.url.getURLForDataRead()+"/tableData/upload"/*"http://127.0.0.1:4000/tableData/upload"*/);
                this.httpCall.send(formData);
                this._spinner.innerSpinShow();
            }
            else
            {
                console.log("Already available");
                this.selectFileErrmsg="A file exist with this name. Please enter different name";
                this.myForm.controls.fileName.reset();
            }
        }
        else
        {
            this.selectFileErrmsg="";
        }
    }

    abortUpload(e){
        this.httpCall.abort();
    }
    progressHnadler(e){
       // console.log("IN progressHnadler");
        //console.log(e);
        let percent = Math.round((e.loaded/e.total)*100);

        this.progressStatus= percent;
        //jQuery('#progressBar').value = Number(percent);
        //console.log(this.progressStatus);
    }
    completeHandler(e){
        console.log("IN completeHandler");
        console.log(e);
        this.getUploadedFilesData();
        this.selectedFilesList=undefined;
        this.myForm.reset();
        this._spinner.innerSpinHide();
        //jQuery('#progressBar').value = 100;
    }
    errorHandler(e){
        console.log("IN errorHandler");
        console.log(e);
        this._spinner.innerSpinHide();
    }
    abortHandler(e){
        console.log("IN abortHandler");
        console.log(e);
        this._spinner.innerSpinHide();
    }
    deleteFile(e){
        console.log(e);
        try{
            this._spinner.innerSpinShow();
            var paramsForData={};
            let query={}, projectQuery={};
            paramsForData["projectQuery"]=projectQuery;
            paramsForData["dataQuery"]= query;
            paramsForData["namespace"]= this.nsObj.getNameSpace("uploads");
            paramsForData["limit"]=-1;
            paramsForData["fileID"]=e._id;
            console.log(paramsForData);

            this.tableDataCollectService.deleteUploaded(paramsForData)
                .subscribe(result => {
                    var res = result;//json();
                    console.log("Delete Res");
                    console.log(res);
                    this._spinner.innerSpinHide();
                    this.getUploadedFilesData();
            });

        }
        catch(e)
        {
            console.log("deleteUploaded File Failed... ");
            this._spinner.innerSpinHide();
        }
    }

      subcribeToFormChanges() {
        this.myForm.statusChanges.subscribe(x =>{
          //console.log(x);
            if((String(x)=="VALID")||(String(x)=="valid"))
            {
              //this.step1Validition=true;
            }
            else{
              //this.step1Validition=false;
            }
            });

      }
      convertBytesToMegaBytes(data:any)
      {
        if((data!=undefined)&&(data!=undefined))
        {
          let packetCount = Number(data);
          var ext="";
          data = (packetCount)/1024; //KB
          ext=" KB";
          //console.log("Data : "+data);
          data = Math.round(data);
          var dataStr="0";
          if( (ext==" KB")&&(data>1024) )
          {
              data = data/1024; //MB
              //data = Math.round(data);
              dataStr= data.toFixed(3);
              ext=" MB";
          }
          else
          {
            dataStr= data.toFixed(3);
            ext=" KB";
          }
          if( (ext==" MB")&&(data>1024) )
          {
              data = data/1024; //MB
              dataStr = data.toFixed(3);
              ext=" GB";
          }
          return String(dataStr)+ext;
        }
        else
          return "0 KB";
      }
}
