import { 
    Component,
    ViewChild, ViewContainerRef, ComponentRef,
    Compiler, ComponentFactory, NgModule, ModuleWithComponentFactories, ComponentFactoryResolver
} from '@angular/core';

import {RunTimeDataProviderService} from "./runtime-content.service"

import { CommonModule } from '@angular/common';

@Component({
    selector: 'runtime-content',
    template: `
        <div>
            <h3>Template</h3>
            <div>
                <textarea rows="5" [(ngModel)]="template"></textarea>
            </div>
            <button (click)="compileTemplate()">Compile</button>
            <h3>Output</h3>
            <div #container></div>
        </div>
    `,
    providers:[RunTimeDataProviderService]
})
export class RuntimeContentComponent {

    template: string = '<div>\nHello, {{name}}\n</div>';

    @ViewChild('container', { read: ViewContainerRef })
    container: ViewContainerRef;
    temp:any= class RuntimeComponent { name: string = 'Denys'; ngAfterViewInit() {
        console.log("In view init");
        console.log(this.name);
      } };
    private componentRef: ComponentRef<{}>;
    tmpUI="<div #container></div> \
            <h3>Hi...</h3>"
    htmlFile:any;
    tsFile:any;
    constructor(
        private componentFactoryResolver: ComponentFactoryResolver,
        private compiler: Compiler,private runtime:RunTimeDataProviderService) {
    }
    ngOnInit(){
    this.runtime.getJSON("assets/pages/org.html").subscribe(data => {
        console.log("RunTime SERVICE>>>>>>");
        this.htmlFile=data._body;
        console.log(data._body);
  
      }, error => console.log(error));
      this.runtime.getJSON("assets/pages/org.ts").subscribe(data => {
        console.log("RunTime SERVICE>>>>>>");
        console.log(data._body);
        this.tsFile= data._body;
  
      }, error => console.log(error));
    }

    compileTemplate() {
        console.log(this.temp);
        console.log("IN compileTemplate");
        let metadata = {
            selector: `runtime-component-sample`,
            template: this.htmlFile
            //`//this.template
        };
        console.log("Before Factory");
        let factory = this.createComponentFactorySync(this.compiler, metadata, null);
        console.log("After Factory");
        if (this.componentRef) {
            this.componentRef.destroy();
            this.componentRef = null;
        }
        console.log("Before creating component ref");
        this.componentRef = this.container.createComponent(factory);
        console.log("After creating component ref");
    }

    private createComponentFactorySync(compiler: Compiler, metadata: Component, componentClass: any): ComponentFactory<any> {
        console.log("in createComponentFactorySync");
        const cmpClass = componentClass || this.tsFile;//class RuntimeComponent { name: string = 'Denys' };
        console.log("after cmpClass");
        
        console.log(cmpClass);
        const decoratedCmp = Component(metadata)(cmpClass);
        console.log("after decoratedCmp");

        @NgModule({ imports: [CommonModule], declarations: [decoratedCmp] })
        class RuntimeComponentModule { }

        let module: ModuleWithComponentFactories<any> = compiler.compileModuleAndAllComponentsSync(RuntimeComponentModule);
        console.log("after Module");
        return module.componentFactories.find(f => {
            console.log("In componentFactories");
            console.log(f.componentType);
            console.log(decoratedCmp);
            return f.componentType === decoratedCmp;});
    }

}