import { Component, OnInit,AfterContentInit, Input , Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import {Http, Headers,Response} from "@angular/http";
import "rxjs/Rx";
import {Observable} from "rxjs";
import * as jQuery from "jquery";
import {RPCService} from "../../../../commonServices/RPC.service";
import {CustomValidator} from "../../../../commonServices/customValidator.service";
import {Logger} from "../../../../commonServices/logger";
import {IMultiSelectOption,IMultiSelectSettings,IMultiSelectTexts} from "../../../../commonModules/multiSelect/types";
@Component({
  selector: 'mediaProfile-add-wizard',
  templateUrl: './mediaProfile-wizard.component.html',
  styleUrls: ['./mediaProfile-wizard.component.scss'],
  providers:[RPCService]
})

export class MediaProfileAddWizardComponent implements OnInit {
    public myForm: FormGroup;
    public submitted: boolean;
    public events: any[] = [];
  step1Validition:boolean=false;

  public user: any;

  @Input() operation:string;
  @Input() data:any;
  @Input() mediaFilesData:any=[];
  @Input() allProfileNames:any=[];
  @Output() closeModalWizard= new EventEmitter<string>();
  @Output() closeModal= new EventEmitter<string>();
  headers:Headers;
  mySettings: IMultiSelectSettings = {
    enableSearch: true,
    checkedStyle: 'fontawesome',
    buttonClasses: 'btn btn-default btn-secondary',//'btn btn-default btn-block',
    dynamicTitleMaxItems: 1,
    displayAllSelectedText: true
};
// Text configuration
myTexts: IMultiSelectTexts = {
    checkAll: 'Select all',
    uncheckAll: 'Unselect all',
    checked: 'item selected',
    checkedPlural: 'items selected',
    searchPlaceholder: 'Find',
    defaultTitle: 'Select',
    allSelected: 'All selected',
};

// Labels / Parents
mediaFileOptions: IMultiSelectOption[] = [];
selectedMediaFiles:any[]=[];


    constructor(private _fb: FormBuilder, private clientRpc: RPCService, private http:Http) {

     }

    ngOnInit() {
        // the long way
        // this.myForm = new FormGroup({
        //     name: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
        //     address: new FormGroup({
        //         address1: new FormControl('', <any>Validators.required),
        //         postcode: new FormControl('8000')
        //     })
        // });
        console.log("Operation : "+this.operation);
        console.log(this.data);
        this.myForm = this._fb.group({
              profileName: ['', [Validators.required, Validators.minLength(5)]],
              files: [[],[Validators.required]]
              //SMPPPassword: ['', [Validators.required, Validators.minLength(5)]],
        });

        this.subcribeToFormChanges();
        console.log(this.mediaFilesData);
        this.mediaFilesData.forEach(loc => {
          loc["id"]=loc._id;
          loc["name"] = loc.filename+" ( Size: "+this.convertBytesToMegaBytes(loc.length)+" )"; //loc.City+"->"+loc.Building+"->"+loc.Floor;
        });
        console.log(this.mediaFilesData);
        this.mediaFilesData.sort(function(a, b) {
            var textA = a.name.toUpperCase();
            var textB = b.name.toUpperCase();
            return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
        });
        this.mediaFileOptions = this.mediaFilesData;

        if(this.operation=="Add")
        {

        }

        if(this.operation=="Modify")
        {
          (<FormControl>this.myForm.controls['profileName'])
          .setValue(this.data.profileName, { onlySelf: true });
            let tempUUID=[],locs=[];
            locs=this.data.files;
            console.log(locs);
            locs.forEach(element => {
              tempUUID.push(element.id);
            });
          (<FormControl> this.myForm.controls["files"])
            .setValue(tempUUID, { onlySelf: true });
          this.step1Validition=true;
        }

    }
    		ngAfterViewInit	(){

      }
      getLocalTime(value){
        return String(new Date(value).toLocaleDateString())+", "+String(new Date(value).toLocaleTimeString());
        }
      onMediaFileSelect(e)
      {
        console.log("onLocationSElect");
        console.log(e);
        try{
        let locsFullData = this.mediaFilesData.filter(val => e.includes(val.id));
        locsFullData.forEach(element => {
          /*let ipv4 = element.IPv4Details;
          let tempIps="";
          for(let i=0;i<ipv4.length;i++)
            {
              if(i>=1)
                {
                  tempIps = tempIps+"...";
                break;
                }
              tempIps = tempIps+ipv4[i].startIPv4+"-"+ipv4[i].endIPv4+"; ";
            }
            element["ips"]=tempIps;*/
        });
        this.selectedMediaFiles = locsFullData;
        console.log(this.selectedMediaFiles);
      }
      catch(e){}
      }
      convertBytesToMegaBytes(data:any)
      {
        if((data!=undefined)&&(data!=undefined))
        {
          let packetCount = Number(data);
          var ext="";
          data = (packetCount)/1024; //KB
          ext=" KB";
          //console.log("Data : "+data);
          data = Math.round(data);
          var dataStr="0";
          if( (ext==" KB")&&(data>1024) )
          {
              data = data/1024; //MB
              //data = Math.round(data);
              dataStr= data.toFixed(3);
              ext=" MB";
          }
          else
          {
            dataStr= data.toFixed(3);
            ext=" KB";
          }
          if( (ext==" MB")&&(data>1024) )
          {
              data = data/1024; //MB
              dataStr = data.toFixed(3);
              ext=" GB";
          }
          return String(dataStr)+ext;
        }
        else
          return "0 KB";
      }

    subcribeToFormChanges() {
      this.myForm.statusChanges.subscribe(x =>{
        //console.log(x);
          if((String(x)=="VALID")||(String(x)=="valid"))
            this.step1Validition=true;
          else
            this.step1Validition=false;
          });


        //const myFormStatusChanges$ = this.myForm.statusChanges;
        //const myFormValueChanges$ = this.myForm.valueChanges;
        //myFormStatusChanges$.subscribe(x => this.events.push({ event: 'STATUS_CHANGED', object: x }));
        //myFormValueChanges$.subscribe(x => this.events.push({ event: 'VALUE_CHANGED', object: x }));
    }

    /*save(model: User, isValid: boolean) {
        this.submitted = true;
        console.log(model, isValid);
    }*/

  gotoFinalSubmit(val:any)
  {
    console.log("Final Submit in add-wizard....");
    console.log(val);
    //Collect all data from each step

    console.log(this.myForm.value);
    let formData = this.myForm.value;

    let locsFullData = this.mediaFilesData.filter(val => formData.files.includes(val.id));
    let locs=[]
      /*locsFullData.forEach(ele => {
        locs.push({"Building" : ele.Building,
        "City" : ele.City,
        "Floor" : ele.Floor,
        "uuid" : ele.uuid});
      });*/
    //console.log(locsFullData);
    formData["files"]=locsFullData;
    
    let finalData = jQuery.extend(formData,{"date":new Date().toISOString()});
  var op;
  if(this.operation=="Add")
    op="create";
  else
  {
    op="update";
    finalData = jQuery.extend(finalData,{"uuid":this.data.uuid});
  }
  console.log(finalData);
  this.clientRpc.orgRPCCall(op,"orgManagerMediaProfileMethod",finalData)
        .subscribe(res =>{
        console.log("OUTPUT...");
        console.log(res);
        let log = new Logger();
        if(String(res.type)=="undefined")
        {
          //log.storeFailNotification("Modify in UserRegistration Failed");
          try{
          if((res.result.status=="Success")||(res.result.Status=="Success"))
          {
            console.log("Trigger reload Event....");
            log.storeSuccessNotification("In Media Management "+this.operation+" succeeded");
          }
          else
          {
            log.storeFailNotification("In Media Management "+this.operation+" Failed");
            console.log("Do Nothing....");
          }
          }
          catch(e){}
        }
        else
        {
          if(String(res.type)=="error")
          {
            log.storeFailNotification("In Media Management "+this.operation+" Failed");
          }
        }
      });
    this.closeModal.emit("yes");
    this.closeModalWizard.emit(val);
    this.myForm.reset();
  }
}
