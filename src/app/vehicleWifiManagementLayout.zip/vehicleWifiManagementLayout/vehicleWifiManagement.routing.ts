import { Routes, RouterModule }  from '@angular/router';
import { VehicleWifiManagementLayout } from './vehicleWifiManagement.component';
import { ModuleWithProviders } from '@angular/core';
// noinspection TypeScriptValidateTypes

// export function loadChildren(path) { return System.import(path); };

export const routes: Routes = [
 
  {
    path: 'vehicleWifiManagementLayout',
    component: VehicleWifiManagementLayout
  }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);
