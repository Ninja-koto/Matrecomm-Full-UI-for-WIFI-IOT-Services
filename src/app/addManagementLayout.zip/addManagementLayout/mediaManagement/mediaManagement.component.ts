import {Component} from "@angular/core"
import {BaThemeSpinner} from "../../theme/services";

@Component({
    selector:'media-mgmt',
    templateUrl:"mediaManagement.component.html"
})

export class MediaManagement{

  mainTab:string = "mediaStoreTab";
    constructor(private _spinner:BaThemeSpinner) {
      this._spinner.show();
    }
    ngAfterViewInit(){
      this._spinner.hide();
    }
    mainTabChanged(e)
    {
      this.mainTab = String(e.tabID);
    }

}