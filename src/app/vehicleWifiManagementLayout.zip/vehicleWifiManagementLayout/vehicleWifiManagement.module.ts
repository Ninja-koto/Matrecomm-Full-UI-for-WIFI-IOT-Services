import {CUSTOM_ELEMENTS_SCHEMA, NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';
import { routing }       from './vehicleWifiManagement.routing';
import { NgaModule } from '../theme/nga.module';
import { VehicleWifiManagementLayout } from './vehicleWifiManagement.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppTranslationModule } from '../app.translation.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { TreeSidebar } from './sidebar/treeSidebar/treeSidebar.component';
import {  TreeMenu } from './sidebar/treeMenu/treeMenu.component';
import {TreeMenuItem } from './sidebar/treeMenu/components/treeMenuItem/treeMenuItem.component';
import { TreeModule } from 'angular-tree-component';
import {TreeComponent} from "../treeComponent/tree.component";
import { TreeComponentModule } from "../commonModules/treeComponent/tree.module";
import {TreeMenuService} from "./sidebar/treeMenu/treeMenu.service";

import { VehicleConfigurationComponent } from "./vehicleConfigurationTable/vehicleConfigurationTable";
import { VehicleConfigurationAddWizardComponent} from "./vehicleConfigurationTable/add-wizard/vehicleConfiguration-wizard.component";

import { GPSVehicleConfigurationComponent } from "./gpsVehicleConfigurationTable/gpsVehicleConfigurationTable";
import { GPSVehicleConfigurationAddWizardComponent} from "./gpsVehicleConfigurationTable/add-wizard/gpsVehicleConfiguration-wizard.component";

import { GPSVehicleRouteConfigurationComponent } from "./gpsVehicleRouteConfigurationTable/gpsVehicleRouteConfigurationTable";
import { GPSVehicleRouteConfigurationAddWizardComponent } from "./gpsVehicleRouteConfigurationTable/add-wizard/gpsVehicleRouteConfiguration-wizard.component";

import { VehiclePolicyComponent } from "./vehiclePolicyTable/vehiclePolicyTable";
import { VehiclePolicyAddWizardComponent } from "./vehiclePolicyTable/add-wizard/vehiclePolicy-wizard.component";

import {TabsPanelModule} from "../commonModules/tabsPanelComponent/tabsPanel.module";
import {CollectionTableModule} from "../commonModules/collectionTable/collectionTable.module";
import { DateTimePickerModule } from 'ng-pick-datetime';

//import {jqueryDragAndDropComponent} from "./dashboard/jqueryDND/jquerydnd.component";
//import {AssignAssetsWizardComponent} from "./dashboard/jqueryDND/assignAssets-wizard/assignAssets.component";
import {ModalModule} from 'ng2-bs4-modal/ng2-bs4-modal';
import {WizardModule} from "../commonModules/wizardComponent/wizard.module";
import {PageTopModule} from "../commonModules/PageTop/PageTop.module";
import {UserManagementModule} from "../orgLayout/userManagement/userManagement.module";

@NgModule({ 
    imports: [
      UserManagementModule,
      PageTopModule,
      TabsPanelModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AppTranslationModule,
    NgaModule,
    routing,
    TreeComponentModule,
    ModalModule,
    CollectionTableModule,
    WizardModule,
    DateTimePickerModule    
    
  ],
  declarations: [
    //jqueryDragAndDropComponent,
    VehicleWifiManagementLayout,
    TreeSidebar,
    TreeMenu,
    TreeMenuItem,
   
    VehicleConfigurationComponent,
    VehicleConfigurationAddWizardComponent,
    GPSVehicleConfigurationComponent,
    GPSVehicleConfigurationAddWizardComponent,
    GPSVehicleRouteConfigurationComponent,
    GPSVehicleRouteConfigurationAddWizardComponent,
    VehiclePolicyComponent,
   VehiclePolicyAddWizardComponent    
    //AssignAssetsWizardComponent
  ],
    exports: [   
    VehicleWifiManagementLayout,
    TreeSidebar,
    TreeMenu,
    TreeMenuItem,
    
  VehicleConfigurationComponent,
VehicleConfigurationAddWizardComponent ,
GPSVehicleConfigurationComponent,
GPSVehicleConfigurationAddWizardComponent,
   GPSVehicleRouteConfigurationComponent,
 GPSVehicleRouteConfigurationAddWizardComponent,
VehiclePolicyComponent,
   VehiclePolicyAddWizardComponent       
 ],
    schemas: [
    CUSTOM_ELEMENTS_SCHEMA
],
  providers: [
    TreeMenuService
  ]
})
export class VehicleWifiManagementLayoutModule {
}
