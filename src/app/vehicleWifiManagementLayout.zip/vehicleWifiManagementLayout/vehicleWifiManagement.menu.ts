export const VEHICLEWIFIMANAGEMENTLAYOUT_MENU = [
  /*{
    path: 'org',
    children: [
      {
        path: 'orgHome',
        data: {
          menu: {
            title: 'Organization Home',
            icon: 'fa fa-home',
            selected: false,
            expanded: false,
            order: 0
          }
        }
      }]
  },*/
  {   
        path: 'vehicleWifiManagementLayout',
        data: {
          menu: {
            title: 'Vehicle Wifi Management',
            icon: 'fa fa-bus',
            selected: false,
            expanded: false,
            order: 0
          }
        }
  }
];
